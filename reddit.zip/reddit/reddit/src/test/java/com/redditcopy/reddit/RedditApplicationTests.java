package com.redditcopy.reddit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedditApplicationTests {

	@Test
	void contextLoads() {
	}

}
